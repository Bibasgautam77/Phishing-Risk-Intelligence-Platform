@echo off
REM Phishing Risk Intelligence Platform - BG-CYBER-002 (Developed by Bibas Gautam)
REM Usage: run.bat          start app and open browser
REM        run.bat seed     load synthetic sample data
REM        run.bat test     run tests
cd /d "%~dp0"
where python >nul 2>&1
if errorlevel 1 (
  echo Python 3.10+ is required. Install from https://www.python.org/downloads/ and tick "Add to PATH".
  pause & exit /b 1
)
if not exist ".venv\Scripts\activate.bat" (
  echo Creating virtual environment...
  python -m venv .venv
)
call ".venv\Scripts\activate.bat"
echo Installing dependencies...
pip install -q fastapi uvicorn pydantic httpx pytest
if errorlevel 1 ( echo Dependency install failed. Check your internet connection. & pause & exit /b 1 )
if /i "%1"=="test" ( python -m pytest -v test_prp.py & pause & exit /b )
if /i "%1"=="seed" ( python prp_app.py seed & pause & exit /b )
start "" cmd /c "timeout /t 4 >nul & start http://127.0.0.1:8000/ui"
python prp_app.py
pause
