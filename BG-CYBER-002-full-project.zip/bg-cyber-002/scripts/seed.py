"""Load SYNTHETIC sample URLs (reserved/fake domains only). Run: python -m scripts.seed"""
from contextlib import closing
from app.main import db, context, store
from app.scoring import analyze, defang

SAMPLES = ["https://example.com/about", "http://paypa1.com@login.evil-example.xyz/verify",
           "http://192.0.2.10:8080/secure/update", "https://bit.ly/abc123",
           "https://microsoft.account-verify.example.top/password"]
with closing(db()) as c:
    bl, w = context(c)
    for u in SAMPLES:
        s, l, f = analyze(u, bl, w)
        print(store(c, defang(u), s, l, f)["id"], l, s)
