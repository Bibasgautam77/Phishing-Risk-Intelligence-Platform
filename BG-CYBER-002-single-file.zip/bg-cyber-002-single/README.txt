Phishing Risk Intelligence Platform - single-file edition
Developed by Bibas Gautam | Project ID: BG-CYBER-002

Windows: double-click run.bat (needs Python 3.10+ on PATH).
  run.bat        start app + open http://127.0.0.1:8000/ui
  run.bat seed   load synthetic sample data
  run.bat test   run tests
Other OS: pip install fastapi uvicorn pydantic httpx pytest ; python prp_app.py

First run creates API keys in prp_keys.txt (plaintext, keep private, never commit).
Paste the analyst or admin key into the UI. Only hashes are used at runtime.

Limitations: heuristic scoring (false positives/negatives expected), short brand list,
SQLite single node, local demo use. Use synthetic data or authorized samples only.
Record real test results honestly after running run.bat test.
