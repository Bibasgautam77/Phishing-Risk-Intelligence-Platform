"""Header/body indicator analysis for a pasted raw email (RFC 822). Nothing is fetched or executed."""
import re
from email import message_from_string, policy
from email.utils import parseaddr
from .scoring import Finding, analyze, defang, label_for, BRANDS

MAX_RAW = 200_000
URGENT = ("urgent", "immediately", "suspended", "verify", "action required", "final notice", "password")


def _dom(addr: str) -> str:
    return parseaddr(addr or "")[1].rpartition("@")[2].lower()


def analyze_email(raw: str, blocklist=None, weights=None):
    if not raw or len(raw) > MAX_RAW:
        raise ValueError("Email must be 1-200000 characters")
    m = message_from_string(raw, policy=policy.default)
    if not m.keys():
        raise ValueError("No headers found; paste the full raw message")
    f: list[Finding] = []
    name, addr = parseaddr(str(m.get("From", "")))
    fd = _dom(str(m.get("From", "")))
    rt, rp = _dom(str(m.get("Reply-To", ""))), _dom(str(m.get("Return-Path", "")))
    if rt and rt != fd:
        f.append(Finding("reply_to_mismatch", 15, f"Reply-To domain ({rt}) differs from From domain ({fd})"))
    if rp and rp != fd:
        f.append(Finding("return_path_mismatch", 10, f"Return-Path domain ({rp}) differs from From domain"))
    for b in BRANDS:
        if b in name.lower() and b not in fd:
            f.append(Finding("display_name_spoof", 25, f"Display name mentions '{b}' but sender domain is {fd}"))
    auth = str(m.get("Authentication-Results", "")).lower()
    if not auth:
        f.append(Finding("no_auth_results", 5, "No Authentication-Results header to verify SPF/DKIM/DMARC"))
    for mech in ("spf", "dkim", "dmarc"):
        if re.search(rf"{mech}=(fail|softfail|none|permerror)", auth):
            f.append(Finding(f"{mech}_fail", 15, f"{mech.upper()} did not pass"))
    subj = str(m.get("Subject", "")).lower()
    hits = [k for k in URGENT if k in subj]
    if hits:
        f.append(Finding("urgent_subject", 10, f"Urgency wording in subject: {', '.join(hits)}"))
    body = m.get_body(preferencelist=("plain", "html"))
    text = body.get_content() if body else ""
    links = list(dict.fromkeys(re.findall(r"https?://[^\s<>\"')]+", text)))[:20]
    worst, worst_url = 0, None
    for u in links:
        try:
            s = analyze(u, blocklist, weights)[0]
        except ValueError:
            continue
        if s > worst:
            worst, worst_url = s, u
    if worst >= 30:
        f.append(Finding("risky_link", round(worst * 0.5), f"Contains risky link {defang(worst_url)} (link score {worst})"))
    for x in f:
        x.points = (weights or {}).get(x.rule, x.points)
    score = min(sum(x.points for x in f), 100)
    return score, label_for(score), f, [defang(u) for u in links]
