# Test Record (BG-CYBER-002)
Run `pytest -v` and paste the real output summary below. Do not edit results to look better.

| Checklist item | Covered by | Result |
|---|---|---|
| Normal input works | test_benign_low, test_url_rules, test_email_phish_high | _fill in_ |
| Invalid/empty/oversized input safe | test_invalid_rejected, test_email_invalid | _fill in_ |
| Unauthorized users blocked | test_auth_and_roles | _fill in_ |
| Errors leak no secrets | test_auth_and_roles (hash not accepted), manual log review | _fill in_ |
| Logs/reports accurate, no secrets | test_flow_redaction_feedback_report, test_email_endpoint_does_not_store_body | _fill in_ |
| Rate limiting | test_rate_limit | _fill in_ |

Run date / environment: _fill in_
