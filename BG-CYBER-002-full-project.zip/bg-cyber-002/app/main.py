import csv, hashlib, io, json, logging, os, sqlite3, time
from collections import defaultdict, deque
from contextlib import closing
from pathlib import Path
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from urllib.parse import urlsplit
from .scoring import analyze, defang, label_for
from .email_analysis import analyze_email
from .reputation import lookup

DB = os.getenv("PRP_DB_PATH", "prp.db")
log = logging.getLogger("prp")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
app = FastAPI(title="Phishing Risk Intelligence Platform", docs_url="/docs")
FOOTER = "Developed by Bibas Gautam | Project ID: BG-CYBER-002"
RANK = {"viewer": 1, "analyst": 2, "admin": 3}
_hits: dict = defaultdict(deque)


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with closing(db()) as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY, url TEXT, score INT, label TEXT, findings TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY, analysis_id INT, verdict TEXT, note TEXT, analyst TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS blocklist(host TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS weights(rule TEXT PRIMARY KEY, points INT);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, actor TEXT, action TEXT, ts REAL);""")
        c.commit()


init_db()


def keys() -> dict:
    """PRP_API_KEYS = '<sha256-hex>:<role>,...' (hashes only; plaintext keys are never stored)."""
    out = {}
    for pair in os.getenv("PRP_API_KEYS", "").split(","):
        if ":" in pair:
            h, r = pair.strip().rsplit(":", 1)
            out[h.lower()] = r
    return out


def auth(min_role: str):
    def dep(x_api_key: str = Header(default="")):
        h = hashlib.sha256(x_api_key.encode()).hexdigest()
        role = keys().get(h)
        if role not in RANK:
            raise HTTPException(401, "Invalid or missing API key")
        q, now = _hits[h], time.time()
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= int(os.getenv("PRP_RATE_LIMIT", "60")):
            raise HTTPException(429, "Rate limit exceeded")
        q.append(now)
        if RANK[role] < RANK[min_role]:
            raise HTTPException(403, "Insufficient permissions")
        return f"{role}:{h[:6]}"
    return dep


def audit(actor, action):
    with closing(db()) as c:
        c.execute("INSERT INTO audit(actor,action,ts) VALUES(?,?,?)", (actor, action, time.time()))
        c.commit()
    log.info("audit actor=%s action=%s", actor, action)


def context(c):
    return ({r["host"] for r in c.execute("SELECT host FROM blocklist")},
            {r["rule"]: r["points"] for r in c.execute("SELECT rule,points FROM weights")})


def store(c, label_text, score, label, findings, extra=None):
    fj = [f.__dict__ for f in findings]
    cur = c.execute("INSERT INTO analyses(url,score,label,findings,ts) VALUES(?,?,?,?,?)",
                    (label_text, score, label, json.dumps(fj), time.time()))
    c.commit()
    return {"id": cur.lastrowid, "url": label_text, "score": score, "label": label,
            "reasons": fj, "footer": FOOTER, **(extra or {})}


class UrlIn(BaseModel):
    url: str = Field(max_length=2048)


class EmailIn(BaseModel):
    raw: str = Field(max_length=200000)


class FeedbackIn(BaseModel):
    verdict: str = Field(pattern="^(false_positive|confirmed_phish|unsure)$")
    note: str = Field(default="", max_length=500)


class WeightIn(BaseModel):
    points: int = Field(ge=0, le=100)


class BlockIn(BaseModel):
    host: str = Field(pattern=r"^[a-z0-9.-]{3,253}$")


@app.post("/analyze")
def post_analyze(body: UrlIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        bl, w = context(c)
        try:
            score, label, findings = analyze(body.url, bl, w)
        except ValueError as e:
            raise HTTPException(422, str(e))
        hit = lookup(urlsplit(body.url).hostname or "")
        if hit:
            findings.append(hit)
            score = min(score + hit.points, 100)
            label = label_for(score)
        res = store(c, defang(body.url), score, label, findings)
    audit(actor, f"analyze:{res['id']}")
    return res


@app.post("/analyze-email")
def post_email(body: EmailIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        bl, w = context(c)
        try:
            score, label, findings, links = analyze_email(body.raw, bl, w)
        except ValueError as e:
            raise HTTPException(422, str(e))
        res = store(c, "email message (body not stored)", score, label, findings, {"links": links})
    audit(actor, f"analyze-email:{res['id']}")
    return res


@app.get("/analyses/{aid}")
def get_analysis(aid: int, actor: str = Depends(auth("viewer"))):
    with closing(db()) as c:
        r = c.execute("SELECT * FROM analyses WHERE id=?", (aid,)).fetchone()
        fb = [dict(x) for x in c.execute("SELECT verdict,note,analyst,ts FROM feedback WHERE analysis_id=?", (aid,))]
    if not r:
        raise HTTPException(404, "Not found")
    return {**dict(r), "findings": json.loads(r["findings"]), "feedback": fb}


@app.post("/analyses/{aid}/feedback")
def post_feedback(aid: int, body: FeedbackIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        if not c.execute("SELECT 1 FROM analyses WHERE id=?", (aid,)).fetchone():
            raise HTTPException(404, "Not found")
        c.execute("INSERT INTO feedback(analysis_id,verdict,note,analyst,ts) VALUES(?,?,?,?,?)",
                  (aid, body.verdict, body.note, actor, time.time()))
        c.commit()
    audit(actor, f"feedback:{aid}:{body.verdict}")
    return {"ok": True}


@app.get("/rules/stats")
def rule_stats(actor: str = Depends(auth("viewer"))):
    """Per-rule firing counts and false-positive counts, to guide weight tuning."""
    stats: dict = defaultdict(lambda: {"fired": 0, "false_positive": 0})
    with closing(db()) as c:
        rows = c.execute("""SELECT a.findings,(SELECT verdict FROM feedback f WHERE f.analysis_id=a.id
                            ORDER BY f.id DESC LIMIT 1) v FROM analyses a""").fetchall()
        weights = {r["rule"]: r["points"] for r in c.execute("SELECT rule,points FROM weights")}
    for r in rows:
        for f in json.loads(r["findings"]):
            stats[f["rule"]]["fired"] += 1
            stats[f["rule"]]["false_positive"] += r["v"] == "false_positive"
    return {"rules": stats, "overrides": weights}


@app.put("/rules/{rule}/weight")
def set_weight(rule: str, body: WeightIn, actor: str = Depends(auth("admin"))):
    if not rule.replace("_", "").isalnum() or len(rule) > 40:
        raise HTTPException(422, "Invalid rule name")
    with closing(db()) as c:
        c.execute("INSERT OR REPLACE INTO weights(rule,points) VALUES(?,?)", (rule, body.points))
        c.commit()
    audit(actor, f"weight:{rule}={body.points}")
    return {"ok": True}


@app.post("/blocklist")
def add_block(body: BlockIn, actor: str = Depends(auth("admin"))):
    with closing(db()) as c:
        c.execute("INSERT OR IGNORE INTO blocklist(host) VALUES(?)", (body.host,))
        c.commit()
    audit(actor, f"blocklist:{body.host}")
    return {"ok": True}


@app.get("/report")
def report(format: str = "json", actor: str = Depends(auth("viewer"))):
    with closing(db()) as c:
        rows = [dict(r) for r in c.execute("""SELECT a.id,a.url,a.score,a.label,
            (SELECT verdict FROM feedback f WHERE f.analysis_id=a.id ORDER BY f.id DESC LIMIT 1) AS latest_verdict
            FROM analyses a ORDER BY a.id DESC LIMIT 500""")]
    audit(actor, f"report:{format}")
    if format == "csv":
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=["id", "url", "score", "label", "latest_verdict"])
        w.writeheader()
        w.writerows(rows)
        buf.write(f"# {FOOTER}\n")
        return Response(buf.getvalue(), media_type="text/csv",
                        headers={"Content-Disposition": "attachment; filename=prp_report.csv"})
    return {"items": rows, "footer": FOOTER}


@app.get("/audit")
def get_audit(actor: str = Depends(auth("admin"))):
    with closing(db()) as c:
        return [dict(r) for r in c.execute("SELECT actor,action,ts FROM audit ORDER BY id DESC LIMIT 200")]


@app.get("/health")
def health():
    return {"status": "ok"}


_static = Path(__file__).resolve().parent.parent / "static"
app.mount("/ui", StaticFiles(directory=_static, html=True), name="ui")
