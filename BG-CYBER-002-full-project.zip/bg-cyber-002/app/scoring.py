"""Safe, offline URL analysis. Never fetches or resolves the URL."""
import ipaddress, re
from dataclasses import dataclass
from urllib.parse import urlsplit, unquote

MAX_LEN = 2048
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "ow.ly"}
RISKY_TLDS = {"zip", "xyz", "top", "click", "gq", "tk", "work", "support"}
KEYWORDS = ("login", "verify", "secure", "update", "account", "password", "wallet", "invoice")
BRANDS = ("paypal", "microsoft", "google", "apple", "amazon", "facebook", "netflix")


@dataclass
class Finding:
    rule: str
    points: int
    reason: str


def _edit1(a: str, b: str) -> bool:
    """True if a and b differ by exactly one edit (lookalike check)."""
    if a == b or abs(len(a) - len(b)) > 1:
        return False
    i = j = d = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
            continue
        d += 1
        if d > 1:
            return False
        if len(a) > len(b): i += 1
        elif len(a) < len(b): j += 1
        else: i += 1; j += 1
    return d + (len(a) - i) + (len(b) - j) == 1


def defang(url: str) -> str:
    """Strip query/fragment (may hold tokens) and defang for safe storage/display."""
    p = urlsplit(url)
    base = f"{p.scheme}://{p.netloc}{p.path}"
    return base.replace("http", "hxxp", 1).replace(".", "[.]")


def label_for(score: int) -> str:
    return "high" if score >= 60 else "medium" if score >= 30 else "low"


def analyze(url: str, blocklist: set[str] | None = None, weights: dict | None = None) -> tuple[int, str, list[Finding]]:
    url = (url or "").strip()
    if not url or len(url) > MAX_LEN:
        raise ValueError("URL must be 1-2048 characters")
    if re.search(r"[\x00-\x1f\s]", url):
        raise ValueError("URL contains whitespace or control characters")
    p = urlsplit(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Only well-formed http/https URLs are supported")
    host = p.hostname.lower()
    f: list[Finding] = []

    if blocklist and host in blocklist:
        f.append(Finding("local_blocklist", 60, f"Host {host} is on the local blocklist"))
    try:
        ipaddress.ip_address(host)
        f.append(Finding("ip_host", 25, "Host is a raw IP address instead of a domain"))
    except ValueError:
        labels = host.split(".")
        if host in SHORTENERS:
            f.append(Finding("shortener", 15, "URL shortener hides the real destination"))
        if labels[-1] in RISKY_TLDS:
            f.append(Finding("risky_tld", 10, f"TLD .{labels[-1]} is frequently abused"))
        if len(labels) > 4:
            f.append(Finding("deep_subdomains", 10, f"{len(labels)} domain labels; deep nesting can mimic trusted names"))
        if any(l.startswith("xn--") for l in labels):
            f.append(Finding("punycode", 20, "Punycode (xn--) label may hide look-alike characters"))
        core = labels[-2] if len(labels) >= 2 else host
        for b in BRANDS:
            if _edit1(core, b):
                f.append(Finding("brand_lookalike", 30, f"'{core}' is one edit away from '{b}'"))
            elif b in labels[:-2] or (b in core and core != b):
                f.append(Finding("brand_in_subdomain", 20, f"Brand '{b}' appears but domain is not {b}.com"))
    if p.username or "@" in p.netloc:
        f.append(Finding("userinfo", 25, "Credentials-style '@' in URL can disguise the real host"))
    if p.port and p.port not in (80, 443):
        f.append(Finding("odd_port", 10, f"Non-standard port {p.port}"))
    if p.scheme == "http":
        f.append(Finding("no_tls", 5, "Unencrypted HTTP"))
    text = unquote(host + p.path).lower()
    hits = [k for k in KEYWORDS if k in text]
    if hits:
        f.append(Finding("keywords", min(5 * len(hits), 15), f"Urgency/credential keywords: {', '.join(hits)}"))
    if url.count("%") > 5:
        f.append(Finding("heavy_encoding", 10, "Heavy percent-encoding may obfuscate content"))
    if len(url) > 200:
        f.append(Finding("long_url", 5, f"Unusually long URL ({len(url)} chars)"))

    for x in f:  # analyst-tuned weights override defaults
        x.points = (weights or {}).get(x.rule, x.points)
    score = min(sum(x.points for x in f), 100)
    return score, label_for(score), f
