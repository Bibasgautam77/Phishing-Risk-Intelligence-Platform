import hashlib, os, tempfile
H = lambda k: hashlib.sha256(k.encode()).hexdigest()
os.environ["PRP_DB_PATH"] = tempfile.mktemp(suffix=".db")
os.environ["PRP_API_KEYS"] = f"{H('ka')}:analyst,{H('kv')}:viewer,{H('kz')}:admin"
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.scoring import analyze
from app.email_analysis import analyze_email

c = TestClient(app)
A, V, Z = ({"X-API-Key": k} for k in ("ka", "kv", "kz"))
PHISH = """From: "PayPal Support" <alert@paypa1-secure.example.top>
Reply-To: help@other.example.xyz
Subject: URGENT: verify your account
Authentication-Results: mx; spf=fail; dkim=none; dmarc=fail

Click http://192.0.2.7/login/verify now
"""


def test_benign_low():
    assert analyze("https://example.com/about")[1] == "low"


def test_url_rules():
    s, _, f = analyze("http://paypa1.com@login.evil.xyz/verify")
    assert {"userinfo", "risky_tld", "keywords"} <= {x.rule for x in f} and s >= 30
    assert "ip_host" in {x.rule for x in analyze("http://192.0.2.5/x")[2]}


def test_weight_override():
    assert analyze("http://192.0.2.5/", weights={"ip_host": 0})[0] < analyze("http://192.0.2.5/")[0]


@pytest.mark.parametrize("bad", ["", "ftp://a.com", "http://", "a b", "http://a.com/" + "x" * 3000])
def test_invalid_rejected(bad):
    with pytest.raises(ValueError):
        analyze(bad)


def test_email_phish_high():
    s, label, f, links = analyze_email(PHISH)
    rules = {x.rule for x in f}
    assert label == "high" and {"reply_to_mismatch", "display_name_spoof", "spf_fail", "risky_link"} <= rules
    assert links and "hxxp" in links[0]


def test_email_invalid():
    for bad in ["", "no headers here", "x" * 300000]:
        with pytest.raises(ValueError):
            analyze_email(bad)


def test_auth_and_roles():
    assert c.post("/analyze", json={"url": "http://a.com"}).status_code == 401
    assert c.post("/analyze", json={"url": "http://a.com"}, headers={"X-API-Key": H("ka")}).status_code == 401  # hash is not a key
    assert c.post("/analyze", json={"url": "http://a.com"}, headers=V).status_code == 403
    assert c.put("/rules/ip_host/weight", json={"points": 5}, headers=A).status_code == 403
    assert c.get("/audit", headers=A).status_code == 403
    assert c.put("/rules/ip_host/weight", json={"points": 5}, headers=Z).status_code == 200


def test_flow_redaction_feedback_report():
    r = c.post("/analyze", json={"url": "http://bit.ly/x?token=SECRET"}, headers=A).json()
    assert "SECRET" not in str(r) and "hxxp" in r["url"] and r["reasons"]
    assert c.post(f"/analyses/{r['id']}/feedback", json={"verdict": "false_positive"}, headers=A).status_code == 200
    assert c.post(f"/analyses/{r['id']}/feedback", json={"verdict": "bogus"}, headers=A).status_code == 422
    assert c.get(f"/analyses/{r['id']}", headers=V).json()["feedback"]
    assert c.get("/rules/stats", headers=V).json()["rules"]["shortener"]["false_positive"] >= 1
    assert "id,url,score" in c.get("/report?format=csv", headers=V).text
    assert c.post("/analyze", json={"url": "nope"}, headers=A).status_code == 422
    assert c.get("/analyses/99999", headers=V).status_code == 404


def test_email_endpoint_does_not_store_body():
    r = c.post("/analyze-email", json={"raw": PHISH}, headers=A).json()
    assert "Click" not in str(r) and r["label"] == "high"


def test_rate_limit(monkeypatch):
    monkeypatch.setenv("PRP_RATE_LIMIT", "3")
    codes = [c.get("/report", headers={"X-API-Key": "kv"}).status_code for _ in range(6)]
    assert 429 in codes
