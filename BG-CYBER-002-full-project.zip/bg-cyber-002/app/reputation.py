"""Optional reputation lookup. Disabled unless PRP_INTEL_URL is set (use only an authorized source).
Sends ONLY the hostname. Expected JSON reply: {"malicious": bool, "source": "name"}."""
import logging, os
import httpx
from .scoring import Finding

log = logging.getLogger("prp.intel")


def lookup(host: str) -> Finding | None:
    url = os.getenv("PRP_INTEL_URL")
    if not url:
        return None
    try:
        h = {"Authorization": f"Bearer {os.getenv('PRP_INTEL_KEY', '')}"}
        r = httpx.get(url, params={"host": host}, headers=h, timeout=3)
        r.raise_for_status()
        d = r.json()
        if d.get("malicious"):
            return Finding("reputation_hit", 50, f"Reputation source '{str(d.get('source', 'unknown'))[:40]}' lists this host as malicious")
    except Exception as e:  # never leak key/URL details; fail open with a log line
        log.warning("intel lookup failed: %s", type(e).__name__)
    return None
