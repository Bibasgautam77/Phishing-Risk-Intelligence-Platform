"""Phishing Risk Intelligence Platform - single-file edition.
Developed by Bibas Gautam | Project ID: BG-CYBER-002
Run: python prp_app.py   (or run.bat on Windows)   Seed demo data: python prp_app.py seed
"""

# ===== scoring =====
"""Safe, offline URL analysis. Never fetches or resolves the URL."""
import ipaddress, re
from dataclasses import dataclass
from urllib.parse import urlsplit, unquote

MAX_LEN = 2048
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "ow.ly"}
RISKY_TLDS = {"zip", "xyz", "top", "click", "gq", "tk", "work", "support"}
KEYWORDS = ("login", "verify", "secure", "update", "account", "password", "wallet", "invoice")
BRANDS = ("paypal", "microsoft", "google", "apple", "amazon", "facebook", "netflix")


@dataclass
class Finding:
    rule: str
    points: int
    reason: str


def _edit1(a: str, b: str) -> bool:
    """True if a and b differ by exactly one edit (lookalike check)."""
    if a == b or abs(len(a) - len(b)) > 1:
        return False
    i = j = d = 0
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            i += 1; j += 1
            continue
        d += 1
        if d > 1:
            return False
        if len(a) > len(b): i += 1
        elif len(a) < len(b): j += 1
        else: i += 1; j += 1
    return d + (len(a) - i) + (len(b) - j) == 1


def defang(url: str) -> str:
    """Strip query/fragment (may hold tokens) and defang for safe storage/display."""
    p = urlsplit(url)
    base = f"{p.scheme}://{p.netloc}{p.path}"
    return base.replace("http", "hxxp", 1).replace(".", "[.]")


def label_for(score: int) -> str:
    return "high" if score >= 60 else "medium" if score >= 30 else "low"


def analyze(url: str, blocklist: set[str] | None = None, weights: dict | None = None) -> tuple[int, str, list[Finding]]:
    url = (url or "").strip()
    if not url or len(url) > MAX_LEN:
        raise ValueError("URL must be 1-2048 characters")
    if re.search(r"[\x00-\x1f\s]", url):
        raise ValueError("URL contains whitespace or control characters")
    p = urlsplit(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise ValueError("Only well-formed http/https URLs are supported")
    host = p.hostname.lower()
    f: list[Finding] = []

    if blocklist and host in blocklist:
        f.append(Finding("local_blocklist", 60, f"Host {host} is on the local blocklist"))
    try:
        ipaddress.ip_address(host)
        f.append(Finding("ip_host", 25, "Host is a raw IP address instead of a domain"))
    except ValueError:
        labels = host.split(".")
        if host in SHORTENERS:
            f.append(Finding("shortener", 15, "URL shortener hides the real destination"))
        if labels[-1] in RISKY_TLDS:
            f.append(Finding("risky_tld", 10, f"TLD .{labels[-1]} is frequently abused"))
        if len(labels) > 4:
            f.append(Finding("deep_subdomains", 10, f"{len(labels)} domain labels; deep nesting can mimic trusted names"))
        if any(l.startswith("xn--") for l in labels):
            f.append(Finding("punycode", 20, "Punycode (xn--) label may hide look-alike characters"))
        core = labels[-2] if len(labels) >= 2 else host
        for b in BRANDS:
            if _edit1(core, b):
                f.append(Finding("brand_lookalike", 30, f"'{core}' is one edit away from '{b}'"))
            elif b in labels[:-2] or (b in core and core != b):
                f.append(Finding("brand_in_subdomain", 20, f"Brand '{b}' appears but domain is not {b}.com"))
    if p.username or "@" in p.netloc:
        f.append(Finding("userinfo", 25, "Credentials-style '@' in URL can disguise the real host"))
    if p.port and p.port not in (80, 443):
        f.append(Finding("odd_port", 10, f"Non-standard port {p.port}"))
    if p.scheme == "http":
        f.append(Finding("no_tls", 5, "Unencrypted HTTP"))
    text = unquote(host + p.path).lower()
    hits = [k for k in KEYWORDS if k in text]
    if hits:
        f.append(Finding("keywords", min(5 * len(hits), 15), f"Urgency/credential keywords: {', '.join(hits)}"))
    if url.count("%") > 5:
        f.append(Finding("heavy_encoding", 10, "Heavy percent-encoding may obfuscate content"))
    if len(url) > 200:
        f.append(Finding("long_url", 5, f"Unusually long URL ({len(url)} chars)"))

    for x in f:  # analyst-tuned weights override defaults
        x.points = (weights or {}).get(x.rule, x.points)
    score = min(sum(x.points for x in f), 100)
    return score, label_for(score), f

# ===== reputation =====
"""Optional reputation lookup. Disabled unless PRP_INTEL_URL is set (use only an authorized source).
Sends ONLY the hostname. Expected JSON reply: {"malicious": bool, "source": "name"}."""
import logging, os
import httpx

log = logging.getLogger("prp.intel")


def lookup(host: str) -> Finding | None:
    url = os.getenv("PRP_INTEL_URL")
    if not url:
        return None
    try:
        h = {"Authorization": f"Bearer {os.getenv('PRP_INTEL_KEY', '')}"}
        r = httpx.get(url, params={"host": host}, headers=h, timeout=3)
        r.raise_for_status()
        d = r.json()
        if d.get("malicious"):
            return Finding("reputation_hit", 50, f"Reputation source '{str(d.get('source', 'unknown'))[:40]}' lists this host as malicious")
    except Exception as e:  # never leak key/URL details; fail open with a log line
        log.warning("intel lookup failed: %s", type(e).__name__)
    return None

# ===== email analysis =====
"""Header/body indicator analysis for a pasted raw email (RFC 822). Nothing is fetched or executed."""
import re
from email import message_from_string, policy
from email.utils import parseaddr

MAX_RAW = 200_000
URGENT = ("urgent", "immediately", "suspended", "verify", "action required", "final notice", "password")


def _dom(addr: str) -> str:
    return parseaddr(addr or "")[1].rpartition("@")[2].lower()


def analyze_email(raw: str, blocklist=None, weights=None):
    if not raw or len(raw) > MAX_RAW:
        raise ValueError("Email must be 1-200000 characters")
    m = message_from_string(raw, policy=policy.default)
    if not m.keys():
        raise ValueError("No headers found; paste the full raw message")
    f: list[Finding] = []
    name, addr = parseaddr(str(m.get("From", "")))
    fd = _dom(str(m.get("From", "")))
    rt, rp = _dom(str(m.get("Reply-To", ""))), _dom(str(m.get("Return-Path", "")))
    if rt and rt != fd:
        f.append(Finding("reply_to_mismatch", 15, f"Reply-To domain ({rt}) differs from From domain ({fd})"))
    if rp and rp != fd:
        f.append(Finding("return_path_mismatch", 10, f"Return-Path domain ({rp}) differs from From domain"))
    for b in BRANDS:
        if b in name.lower() and b not in fd:
            f.append(Finding("display_name_spoof", 25, f"Display name mentions '{b}' but sender domain is {fd}"))
    auth = str(m.get("Authentication-Results", "")).lower()
    if not auth:
        f.append(Finding("no_auth_results", 5, "No Authentication-Results header to verify SPF/DKIM/DMARC"))
    for mech in ("spf", "dkim", "dmarc"):
        if re.search(rf"{mech}=(fail|softfail|none|permerror)", auth):
            f.append(Finding(f"{mech}_fail", 15, f"{mech.upper()} did not pass"))
    subj = str(m.get("Subject", "")).lower()
    hits = [k for k in URGENT if k in subj]
    if hits:
        f.append(Finding("urgent_subject", 10, f"Urgency wording in subject: {', '.join(hits)}"))
    body = m.get_body(preferencelist=("plain", "html"))
    text = body.get_content() if body else ""
    links = list(dict.fromkeys(re.findall(r"https?://[^\s<>\"')]+", text)))[:20]
    worst, worst_url = 0, None
    for u in links:
        try:
            s = analyze(u, blocklist, weights)[0]
        except ValueError:
            continue
        if s > worst:
            worst, worst_url = s, u
    if worst >= 30:
        f.append(Finding("risky_link", round(worst * 0.5), f"Contains risky link {defang(worst_url)} (link score {worst})"))
    for x in f:
        x.points = (weights or {}).get(x.rule, x.points)
    score = min(sum(x.points for x in f), 100)
    return score, label_for(score), f, [defang(u) for u in links]

# ===== api =====
import csv, hashlib, io, json, logging, os, sqlite3, time
from collections import defaultdict, deque
from contextlib import closing
from pathlib import Path
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import Response, HTMLResponse
from pydantic import BaseModel, Field
from urllib.parse import urlsplit

DB = os.getenv("PRP_DB_PATH", "prp.db")
log = logging.getLogger("prp")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
app = FastAPI(title="Phishing Risk Intelligence Platform", docs_url="/docs")
FOOTER = "Developed by Bibas Gautam | Project ID: BG-CYBER-002"
RANK = {"viewer": 1, "analyst": 2, "admin": 3}
_hits: dict = defaultdict(deque)


def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    with closing(db()) as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY, url TEXT, score INT, label TEXT, findings TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY, analysis_id INT, verdict TEXT, note TEXT, analyst TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS blocklist(host TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS weights(rule TEXT PRIMARY KEY, points INT);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, actor TEXT, action TEXT, ts REAL);""")
        c.commit()



def bootstrap_keys():
    """If PRP_API_KEYS is unset, create admin/analyst/viewer keys on first run (local demo convenience).
    Plaintext keys go to prp_keys.txt (keep private, never commit); only hashes are used at runtime."""
    if os.getenv("PRP_API_KEYS"):
        return
    hf = Path("prp_hashes.txt")
    if not hf.exists():
        import secrets
        plain, hashes = [], []
        for role in ("admin", "analyst", "viewer"):
            k = secrets.token_urlsafe(32)
            plain.append(f"{role}: {k}")
            hashes.append(f"{hashlib.sha256(k.encode()).hexdigest()}:{role}")
        Path("prp_keys.txt").write_text("\n".join(plain) + "\n")
        hf.write_text(",".join(hashes))
        print("First run: API keys written to prp_keys.txt (paste one into the UI).")
    os.environ["PRP_API_KEYS"] = hf.read_text().strip()


bootstrap_keys()
init_db()


def keys() -> dict:
    """PRP_API_KEYS = '<sha256-hex>:<role>,...' (hashes only; plaintext keys are never stored)."""
    out = {}
    for pair in os.getenv("PRP_API_KEYS", "").split(","):
        if ":" in pair:
            h, r = pair.strip().rsplit(":", 1)
            out[h.lower()] = r
    return out


def auth(min_role: str):
    def dep(x_api_key: str = Header(default="")):
        h = hashlib.sha256(x_api_key.encode()).hexdigest()
        role = keys().get(h)
        if role not in RANK:
            raise HTTPException(401, "Invalid or missing API key")
        q, now = _hits[h], time.time()
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= int(os.getenv("PRP_RATE_LIMIT", "60")):
            raise HTTPException(429, "Rate limit exceeded")
        q.append(now)
        if RANK[role] < RANK[min_role]:
            raise HTTPException(403, "Insufficient permissions")
        return f"{role}:{h[:6]}"
    return dep


def audit(actor, action):
    with closing(db()) as c:
        c.execute("INSERT INTO audit(actor,action,ts) VALUES(?,?,?)", (actor, action, time.time()))
        c.commit()
    log.info("audit actor=%s action=%s", actor, action)


def context(c):
    return ({r["host"] for r in c.execute("SELECT host FROM blocklist")},
            {r["rule"]: r["points"] for r in c.execute("SELECT rule,points FROM weights")})


def store(c, label_text, score, label, findings, extra=None):
    fj = [f.__dict__ for f in findings]
    cur = c.execute("INSERT INTO analyses(url,score,label,findings,ts) VALUES(?,?,?,?,?)",
                    (label_text, score, label, json.dumps(fj), time.time()))
    c.commit()
    return {"id": cur.lastrowid, "url": label_text, "score": score, "label": label,
            "reasons": fj, "footer": FOOTER, **(extra or {})}


class UrlIn(BaseModel):
    url: str = Field(max_length=2048)


class EmailIn(BaseModel):
    raw: str = Field(max_length=200000)


class FeedbackIn(BaseModel):
    verdict: str = Field(pattern="^(false_positive|confirmed_phish|unsure)$")
    note: str = Field(default="", max_length=500)


class WeightIn(BaseModel):
    points: int = Field(ge=0, le=100)


class BlockIn(BaseModel):
    host: str = Field(pattern=r"^[a-z0-9.-]{3,253}$")


@app.post("/analyze")
def post_analyze(body: UrlIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        bl, w = context(c)
        try:
            score, label, findings = analyze(body.url, bl, w)
        except ValueError as e:
            raise HTTPException(422, str(e))
        hit = lookup(urlsplit(body.url).hostname or "")
        if hit:
            findings.append(hit)
            score = min(score + hit.points, 100)
            label = label_for(score)
        res = store(c, defang(body.url), score, label, findings)
    audit(actor, f"analyze:{res['id']}")
    return res


@app.post("/analyze-email")
def post_email(body: EmailIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        bl, w = context(c)
        try:
            score, label, findings, links = analyze_email(body.raw, bl, w)
        except ValueError as e:
            raise HTTPException(422, str(e))
        res = store(c, "email message (body not stored)", score, label, findings, {"links": links})
    audit(actor, f"analyze-email:{res['id']}")
    return res


@app.get("/analyses/{aid}")
def get_analysis(aid: int, actor: str = Depends(auth("viewer"))):
    with closing(db()) as c:
        r = c.execute("SELECT * FROM analyses WHERE id=?", (aid,)).fetchone()
        fb = [dict(x) for x in c.execute("SELECT verdict,note,analyst,ts FROM feedback WHERE analysis_id=?", (aid,))]
    if not r:
        raise HTTPException(404, "Not found")
    return {**dict(r), "findings": json.loads(r["findings"]), "feedback": fb}


@app.post("/analyses/{aid}/feedback")
def post_feedback(aid: int, body: FeedbackIn, actor: str = Depends(auth("analyst"))):
    with closing(db()) as c:
        if not c.execute("SELECT 1 FROM analyses WHERE id=?", (aid,)).fetchone():
            raise HTTPException(404, "Not found")
        c.execute("INSERT INTO feedback(analysis_id,verdict,note,analyst,ts) VALUES(?,?,?,?,?)",
                  (aid, body.verdict, body.note, actor, time.time()))
        c.commit()
    audit(actor, f"feedback:{aid}:{body.verdict}")
    return {"ok": True}


@app.get("/rules/stats")
def rule_stats(actor: str = Depends(auth("viewer"))):
    """Per-rule firing counts and false-positive counts, to guide weight tuning."""
    stats: dict = defaultdict(lambda: {"fired": 0, "false_positive": 0})
    with closing(db()) as c:
        rows = c.execute("""SELECT a.findings,(SELECT verdict FROM feedback f WHERE f.analysis_id=a.id
                            ORDER BY f.id DESC LIMIT 1) v FROM analyses a""").fetchall()
        weights = {r["rule"]: r["points"] for r in c.execute("SELECT rule,points FROM weights")}
    for r in rows:
        for f in json.loads(r["findings"]):
            stats[f["rule"]]["fired"] += 1
            stats[f["rule"]]["false_positive"] += r["v"] == "false_positive"
    return {"rules": stats, "overrides": weights}


@app.put("/rules/{rule}/weight")
def set_weight(rule: str, body: WeightIn, actor: str = Depends(auth("admin"))):
    if not rule.replace("_", "").isalnum() or len(rule) > 40:
        raise HTTPException(422, "Invalid rule name")
    with closing(db()) as c:
        c.execute("INSERT OR REPLACE INTO weights(rule,points) VALUES(?,?)", (rule, body.points))
        c.commit()
    audit(actor, f"weight:{rule}={body.points}")
    return {"ok": True}


@app.post("/blocklist")
def add_block(body: BlockIn, actor: str = Depends(auth("admin"))):
    with closing(db()) as c:
        c.execute("INSERT OR IGNORE INTO blocklist(host) VALUES(?)", (body.host,))
        c.commit()
    audit(actor, f"blocklist:{body.host}")
    return {"ok": True}


@app.get("/report")
def report(format: str = "json", actor: str = Depends(auth("viewer"))):
    with closing(db()) as c:
        rows = [dict(r) for r in c.execute("""SELECT a.id,a.url,a.score,a.label,
            (SELECT verdict FROM feedback f WHERE f.analysis_id=a.id ORDER BY f.id DESC LIMIT 1) AS latest_verdict
            FROM analyses a ORDER BY a.id DESC LIMIT 500""")]
    audit(actor, f"report:{format}")
    if format == "csv":
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=["id", "url", "score", "label", "latest_verdict"])
        w.writeheader()
        w.writerows(rows)
        buf.write(f"# {FOOTER}\n")
        return Response(buf.getvalue(), media_type="text/csv",
                        headers={"Content-Disposition": "attachment; filename=prp_report.csv"})
    return {"items": rows, "footer": FOOTER}


@app.get("/audit")
def get_audit(actor: str = Depends(auth("admin"))):
    with closing(db()) as c:
        return [dict(r) for r in c.execute("SELECT actor,action,ts FROM audit ORDER BY id DESC LIMIT 200")]


@app.get("/health")
def health():
    return {"status": "ok"}




HTML = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Phishing Risk Intelligence Platform</title>
<style>
:root{--bg:#fff;--fg:#1a1a1a;--card:#f5f6f8;--bd:#d8dbe0;--ac:#2456d6}
@media(prefers-color-scheme:dark){:root{--bg:#14161a;--fg:#e8e8e8;--card:#1d2026;--bd:#333842;--ac:#6b93ff}}
body{margin:0;font:15px system-ui,sans-serif;background:var(--bg);color:var(--fg)}
main{max-width:860px;margin:auto;padding:20px}
textarea,input{width:100%;box-sizing:border-box;padding:8px;background:var(--card);color:var(--fg);border:1px solid var(--bd);border-radius:6px}
button{padding:8px 14px;margin:6px 6px 6px 0;border:0;border-radius:6px;background:var(--ac);color:#fff;cursor:pointer}
.card{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:12px;margin:12px 0}
.low{color:#1a8a3c}.medium{color:#c27a00}.high{color:#d12b2b}
footer{text-align:center;opacity:.7;padding:20px;font-size:13px}
</style></head><body><main><div id="root"></div></main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js"></script>
<script>
const h=React.createElement,{useState}=React;
function App(){
  const[key,setKey]=useState(""),[mode,setMode]=useState("url"),[input,setInput]=useState(""),
  [res,setRes]=useState(null),[err,setErr]=useState(""),[rep,setRep]=useState([]),[note,setNote]=useState("");
  const api=async(path,opt={})=>{const r=await fetch(path,{...opt,headers:{"Content-Type":"application/json","X-API-Key":key}});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.detail||("Error "+r.status));return d};
  const run=async()=>{setErr("");try{setRes(await api(mode==="url"?"/analyze":"/analyze-email",{method:"POST",body:JSON.stringify(mode==="url"?{url:input}:{raw:input})}));loadRep()}catch(e){setErr(e.message)}};
  const loadRep=async()=>{try{setRep((await api("/report")).items)}catch(e){}};
  const fb=async v=>{try{await api(`/analyses/${res.id}/feedback`,{method:"POST",body:JSON.stringify({verdict:v,note})});loadRep();setNote("")}catch(e){setErr(e.message)}};
  return h("div",null,
    h("h1",null,"Phishing Risk Intelligence"),
    h("input",{type:"password",placeholder:"API key (kept in memory only)",value:key,onChange:e=>setKey(e.target.value)}),
    h("div",null,["url","email"].map(m=>h("button",{key:m,onClick:()=>setMode(m),style:{opacity:mode===m?1:.5}},m==="url"?"URL":"Raw email"))),
    h("textarea",{rows:mode==="url"?2:10,placeholder:mode==="url"?"https://example.com/... (never opened or fetched)":"Paste full raw email with headers",value:input,onChange:e=>setInput(e.target.value)}),
    h("button",{onClick:run},"Analyze"),h("button",{onClick:loadRep},"Refresh report"),
    err&&h("div",{className:"card high",role:"alert"},err),
    res&&h("div",{className:"card"},
      h("h3",null,h("span",{className:res.label},res.label.toUpperCase())," — score ",res.score,"/100"),
      h("div",null,res.url),
      h("ul",null,res.reasons.length?res.reasons.map((r,i)=>h("li",{key:i},`+${r.points} ${r.reason}`)):h("li",null,"No risk indicators matched")),
      h("input",{placeholder:"Analyst note (optional)",value:note,maxLength:500,onChange:e=>setNote(e.target.value)}),
      [["false_positive","False positive"],["confirmed_phish","Confirmed phish"],["unsure","Unsure"]].map(([v,t])=>h("button",{key:v,onClick:()=>fb(v)},t))),
    h("h3",null,"Recent analyses"),
    rep.map(r=>h("div",{className:"card",key:r.id},`#${r.id} `,h("b",{className:r.label},r.label)," ",r.score," — ",r.url,r.latest_verdict?` [${r.latest_verdict}]`:"")),
    h("footer",null,"Developed by Bibas Gautam | Project ID: BG-CYBER-002"));
}
ReactDOM.createRoot(document.getElementById("root")).render(h(App));
</script></body></html>
'''


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
@app.get("/ui", response_class=HTMLResponse, include_in_schema=False)
@app.get("/ui/", response_class=HTMLResponse, include_in_schema=False)
def ui():
    return HTML


def seed():
    """Load SYNTHETIC sample URLs only."""
    samples = ["https://example.com/about", "http://paypa1.com@login.evil-example.xyz/verify",
               "http://192.0.2.10:8080/secure/update", "https://bit.ly/abc123",
               "https://microsoft.account-verify.example.top/password"]
    with closing(db()) as c:
        bl, w = context(c)
        for u in samples:
            s, l, f = analyze(u, bl, w)
            print("seeded", store(c, defang(u), s, l, f)["id"], l, s)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "seed":
        seed()
    else:
        import uvicorn
        print("Open http://127.0.0.1:8000/ui  (API docs: /docs)  Press Ctrl+C to stop.")
        uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
