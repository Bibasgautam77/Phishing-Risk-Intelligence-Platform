"""Generate an API key and its SHA-256 hash:  python -m app.mkkey analyst"""
import hashlib, secrets, sys
role = sys.argv[1] if len(sys.argv) > 1 else "analyst"
k = secrets.token_urlsafe(32)
print(f"API key (give to user, store safely): {k}")
print(f"Add to PRP_API_KEYS: {hashlib.sha256(k.encode()).hexdigest()}:{role}")
